ASSIGNMENT PRF192 - FPT University
/* Student Names: Nguyen Hoang Minh - HE168177
*                 Vu Duc Trung      - HE161769
/*                Truong Hoang Hiep - HE161790
*                 Nguyen Minh Cuong - HE161873
/*                Nguyen Tri Phuc   - HE176442 (Leader)

- 1 file SE1739_Group3.c là file chính sau khi combine các code của từng thành viên.
- 5 file stt_hovaten_mssv.c là các file riêng do nhóm trưởng phân chia cho từng thành viên tương ứng
- các file .txt, .bat là các file cần dùng khi chạy các chương trình
- file table.png là ví dụ của trình bày mảng của bài 4
- file demo.c là bản demo để các thành viên tham khảo do leader thực hiện